package com.ssafy.edu.vue.dao;

import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ssafy.edu.vue.dto.BoardDto;

@Repository
public class BoardDao implements BoardMapper {

	String ns = "com.ssafy.edu.vue.";
	
	@Autowired
	private SqlSession sqlSession;

	@Override
	public List<BoardDto> findAllBoards() throws Exception {
		System.out.println("start");
		List<BoardDto> bl = sqlSession.selectList(ns+"findAllBoards");
		System.out.println("end");
		return bl;
	}

	@Override
	public void writeBoard(BoardDto boarddto) throws Exception {
		sqlSession.insert(ns+"writeBoard", boarddto);
	}

	@Override
	public boolean updateBoard(BoardDto boarddto) throws Exception {
		sqlSession.update(ns+"updateBoard", boarddto);
		return true;
	}

	@Override
	public boolean deleteBoard(int seq) throws Exception {
		sqlSession.delete(ns+"deleteBoard", seq);
		return true;
	}

	@Override
	public BoardDto detailBoard(int index) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int findAfterAdd() throws Exception {
		return sqlSession.selectOne(ns+"findAfterAdd");
	}

	@Override
	public BoardDto findBoardBySeq(int seq) {
		return sqlSession.selectOne(ns+"findBoardBySeq", seq);
	}

	@Override
	public List<BoardDto> searchByWriter(String writer) throws Exception {
		return sqlSession.selectList(ns+"searchByWriter", writer);
	}

	@Override
	public List<BoardDto> searchBoard(HashMap<String, String> map) throws Exception {
		return sqlSession.selectList(ns+"searchBoard", map);
	}


}
