package com.ssafy.edu.vue.service;

import java.util.HashMap;
import java.util.List;

import com.ssafy.edu.vue.dto.BoardDto;

public interface IBoardService {
	public List<BoardDto> findAllBoards() throws Exception;
	public int writeBoard(BoardDto boarddto) throws Exception;
	
	public BoardDto findBoardBySeq(int seq) throws Exception;
	
	public boolean updateBoard(BoardDto boarddto) throws Exception;
	public boolean deleteBoard(int seq) throws Exception;
	public BoardDto detailBoard(int seq) throws Exception;
	
	// 게시판 검색관련
	public List<BoardDto> searchBoard(HashMap<String, String> map) throws Exception;
}
