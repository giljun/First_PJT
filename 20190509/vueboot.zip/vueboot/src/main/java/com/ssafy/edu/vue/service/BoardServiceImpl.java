package com.ssafy.edu.vue.service;

import java.util.HashMap;
import java.util.List;

import javax.validation.constraints.AssertTrue;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ssafy.edu.vue.dao.BoardDao;
import com.ssafy.edu.vue.dto.BoardDto;

@Service
public class BoardServiceImpl implements IBoardService {

	@Autowired
	private BoardDao boardDao;
	
	@Override
	public List<BoardDto> findAllBoards() throws Exception {
		return boardDao.findAllBoards();
	}

	@Override
	public int writeBoard(BoardDto boarddto) throws Exception {
		boardDao.writeBoard(boarddto);
		return boardDao.findAfterAdd();
	}

	@Override
	public boolean updateBoard(BoardDto boarddto) throws Exception {
		return boardDao.updateBoard(boarddto);
	}

	@Override
	public boolean deleteBoard(int seq) throws Exception {
		return boardDao.deleteBoard(seq);
	}

	@Override
	public BoardDto detailBoard(int index) throws Exception {
		return null;
	}

	@Override
	public BoardDto findBoardBySeq(int seq) throws Exception {
		return boardDao.findBoardBySeq(seq);
	}

	@Override
	public List<BoardDto> searchBoard(HashMap<String, String> map) throws Exception {
		return boardDao.searchBoard(map);
	}
}
